﻿<#
.SYNOPSIS
Setup a NDES server and configure Certificate Authority for Intune SCEP Integration.

.DESCRIPTION
Configures a NDES server and a Certificate Authority (using a seperate script) to be prepared for use with Intune SCEP.

Steps
1. Make sure that NDES Service Account has the necessary permissions on the NDES server.
2. Send separate script 'Create-NdesCertificateTemplate.ps1' to CA server to be run for CA Template creation and necessary permission delegations.
3. Install and configure NDES roles on the NDES server.
4. Configure IIS.
5. Download and install Entra App Proxy Connector.
6. Create new Entra Proxy App in Entra ID.
7. Requests a new certificate for the NDES server from the CA with the newly created CA Server Template.
8. Setting SPN.
9. Configure IIS HTTPS Binding with newly issued certificate.
10. Download and configure Intune Certificate Connector.

.PARAMETER ServiceAccountCredentials
Credentials for the Service Account used for NDES services

.PARAMETER optionalClientTemplateName
Optional custom name for the client CA Template. Default is 'ScepNdesClient'.

.PARAMETER optionalServerTemplateName
Optional custom name for the server CA Template. Default is 'ScepNdesServer'.

.EXAMPLE
.\Setup-SCEPServer.ps1
Runs script with default CA template names and prompts user for NDES service account credentials.

.EXAMPLE
.\Setup-SCEPServer.ps1 -ServiceAccountCredentials $cred -optionalClientTemplateName 'clientNDES' -optionalServerTemplateName 'serverNDES'
Run script with pre-defined PSCredential object and custom CA certificate template names.

.NOTES


#>

[CmdletBinding()]
param (
    [Parameter(Mandatory=$false)]
    [PSCredential]
    $ServiceAccountCredentials = (Get-Credential -Message "Please provide NDES Service Account credentials"),

    [Parameter(Mandatory=$false)]
    [String]
    $optionalClientTemplateName = "ScepNdesClient",

    [Parameter(Mandatory=$false)]
    [String]
    $optionalServerTemplateName = "ScepNdesServer"
)

##*===============================================
##* Functions
##*===============================================
#region Functions
function Install-ScriptModules{
    param(
        [parameter(Mandatory=$true)]
        [string[]]$Modules = @()
    )

    foreach ($Module in $Modules) {
        $Module
        Clear-Variable CurrentModule -ErrorAction SilentlyContinue
        $ErrorActionPreference = "Stop"
        try{
            Import-Module -Name $Module -Force -ErrorAction SilentlyContinue
            $CurrentModule = Get-Module -Name $Module -ErrorAction SilentlyContinue
            IF(!$CurrentModule){
                try{
                    # Install NuGet package provider
                    $PackageProvider = Install-PackageProvider -Name NuGet -Force -Verbose:$false
                    try {
                        # Install current missing module
                        Install-Module -Name $Module -Force -Confirm:$false

                        # Import installed module
                        Import-Module -Name $Module -Force -ErrorAction SilentlyContinue
                        # Get imported module
                        $CurrentModule = Get-Module -Name $Module -ErrorAction SilentlyContinue
                        IF(!$CurrentModule){
                            # Log module install failed
                            Write-Host "Failed to get module after installation." -F Yellow -B Black
                            Break
                        }
                    }catch [System.Exception] {
                        Write-Host "Failed to install module." -F Yellow -B Black
                        Break
                    }
                }catch [System.Exception] {
                    Write-Host "Failed to install NuGet Package Provider." -F Yellow -B Black
                    Break
                }
            }ELSE{
                # Log module import success
            }
        }catch{
            Break
        }
        $ErrorActionPreference = "Continue"
    }
}

function Add-ServiceLogonRight {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $Username
    )

    Write-Host "Enable ServiceLogonRight for $Username"
    $ErrorActionPreference = "Stop"
    try {
        $tmp = New-TemporaryFile
        secedit /export /cfg "$tmp.inf" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            try {
                (Get-Content -Encoding ASCII "$tmp.inf") -replace '^SeServiceLogonRight .+', "`$0,$Username" | Set-Content -Encoding ASCII "$tmp.inf"
                secedit /import /cfg "$tmp.inf" /db "$tmp.sdb" | Out-Null
                if ($LASTEXITCODE -eq 0) {
                    secedit /configure /db "$tmp.sdb" /cfg "$tmp.inf" | Out-Null
                    if ($LASTEXITCODE -eq 0) {
                        Remove-Item $tmp* -Force -ErrorAction SilentlyContinue
                    } else {
                        Write-Host "Failed to configure SECEDIT settings." -F Red -B Black
                        Pause
                    }
                } else {
                    Write-Host "Failed to import edited SECEDIT settings." -F Red -B Black
                    Pause
                }
            }
            catch {
                Write-Host "Failed to edit exported SECEDIT settings. Error message: $($_.Exception)" -F Red -B Black
                Pause
            }
        } else {
            Throw "Failed to export SECEDIT settings."
            Pause
        }
    } catch {
        Write-Host "Failed to create new temporary file. Error message: $($_.Exception)" -F Red -B Black
        Pause
    }
    $ErrorActionPreference = "Continue"
}

function Test-ADAuth {
    param(
            [parameter(Mandatory=$true)]
            [PSCredential]$Credentials
        )

     # Get current domain using logged-on user's credentials
     try {
        $CurrentDomain = "LDAP://" + ([ADSI]"").distinguishedName
        $domain = New-Object System.DirectoryServices.DirectoryEntry($CurrentDomain, $Credentials.username, $Credentials.GetNetworkCredential().password) -ErrorAction Stop
     }
     catch {
        Write-Host "Failed to test NDES Service Account authentication. Error message: $($_.Exception)" -F Red -B Black
        Pause
     }

    if ($domain.name -eq $null) {
        return $false
    } else {
        return $true
    }
}

#endregion
##*===============================================
##* END Functions
##*===============================================

$currentGroupMembership = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Groups | ForEach-Object -Process { Write-Output $_.Translate([System.Security.Principal.NTAccount]) }).Value
if (($currentGroupMembership -notcontains "$env:USERDOMAIN\Enterprise Admins") -OR ($currentGroupMembership -notcontains "$env:USERDOMAIN\Domain Admins")) {
    Write-Warning "This script must be run with an account with both Domain admin and Enterprise Admin permission!"
    Pause
    Break
}

# Automatically Self-elevate the script if required - http://www.expta.com/2017/03/how-to-self-elevate-powershell-script.html
###################################################################################################################
    # Auto Elevation
    IF (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
        IF ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
            $CommandLine = "-ExecutionPolicy Bypass " + "-File `"" + $MyInvocation.MyCommand.Path + "`" " + $MyInvocation.UnboundArguments
            Start-Process -FilePath PowerShell.exe -Verb Runas -ArgumentList $CommandLine
            Exit
        }
    }

###################################################################################################################

# Install necessary modules
Write-Host "`t Step 1/18 - Installing following modules..." -F Yellow
Install-ScriptModules -Modules ActiveDirectory,AzureAD,PSPKI


# Test user
Write-Host "`t Step 2/18 - Authenticating NDES Service Account..."
 if ($serviceAccount = Get-ADUser $ServiceAccountCredentials.UserName) {
    if (Test-ADAuth -Credentials $ServiceAccountCredentials) {
        Write-Host "NDES Service Account was successfully authenticated!" -F Green -B
    } else {
        Write-Host "NDES Service Account password is incorrect" -F Red -B Black
        Pause
        Break
    }
} else {
    Write-Host "NDES Service Account was not found" -F Red -B Black
    Pause
    Break
}


# Disable IE Enhanced Security
Write-Host "`t Step 3/18 - Disabling IE Enhanced Security..." -F Yellow
try {
    $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
    $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
    Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0 -ErrorAction Stop
    Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0 -ErrorAction Stop
    Stop-Process -Name Explorer -ErrorAction Stop
}
catch {
    Write-Host "Failed to disable IE Enhanced Security. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please disable it manually and contiune."
    Pause
}


Start-Sleep -Seconds 5

# Get Certification Authority
Write-Host "`t Step 4/18 - Discovering Certificate Authorities in domain..." -F Yellow
try {
    $caServers = (Get-CertificationAuthority -ErrorAction Stop | where {($_.IsAccessible) -AND ($_.ServiceStatus -like "Running")})
}
catch {
    Write-Host "Failed to discover Certificate Authorities in domain. Error message: $($_.Exception)" -F Red -B Black
    Pause
    Break
}

if ($caServers.Count -ge 2) {
    $caServer = $caServers | Select -ExcludeProperty Certificate | Out-GridView -Title "Choose CA Server" -OutputMode Single
} elseif (!$caServers) {
    Write-Warning "No CA servers discovered"
    Pause
    Break
} else {
    $caServer = $caServers
}

# Add service account to local IIS_IUSRS group
Write-Host "`t Step 5/18 - Adding NDES Service Account to local groups..." -F Yellow

$domainController = Get-WmiObject -Query "select * from Win32_OperatingSystem where ProductType='2'"
try {
    if ($domainController) {
        Add-ADGroupMember -Identity IIS_IUSRS -Member $serviceAccount.SamAccountName -ErrorAction Stop
    } else {
        Add-LocalGroupMember -Group IIS_IUSRS -Member "$env:USERDOMAIN\$($serviceAccount.SamAccountName)" -ErrorAction Stop
    }
}
catch {
    Write-Host "Failed to add NDES Service Account to local IIS_USRS group. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please manually add NDES Service Account to the local IIS_USRS group and continue."
    Pause
}


# Grant service account logon as as service permission on the server
Write-Host "`t Step 6/18 - Granting NDES Service Account Log on as Service permission..." -F Yellow
try {
    Add-ServiceLogonRight -Username $serviceAccount.SamAccountName -ErrorAction Stop
}
catch {
    Write-Host "An error occurred while adding Service Logon Rights. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please grant NDES Service Account Log on as Service permission on this server and continue."
    Pause
}


# Import Certifcate templates to CA server
## invoke to ca server
Write-Host "`t Step 7/18 - Configuring Certificate Authority..." -F Yellow
$certArgs = "-ServiceAccountUsername $($serviceAccount.SamAccountName) -serverTemplateName $optionalServerTemplateName -clientTemplateName $optionalClientTemplateName"
if (Test-WSMan $caServer.ComputerName) {
    Write-Host "Sending the script 'Create-NdesCertificateTemplates.ps1' to be run on $($caServer.ComputerName)..."
    try {
        Invoke-Command -ComputerName $caServer.ComputerName -FilePath $PSScriptRoot\Create-NdesCertificateTemplate.ps1 -ArgumentList $certArgs -ErrorAction Stop
    }
    catch {
        Write-Host "Failed to invoke script to CA server $($caServer.Computername). Error message: $($_.Exception)" -F Red -B Black
        Write-Warning "Please run the script 'Create-NdesCertificateTemplates.ps1' manually on $($caServer.ComputerName) and then continue this script. Make sure to use the following parameters when running the script:`n`nCreate-NdesCertificateTemplates.ps1 $certArgs"
        Pause
    }
} else {
    Write-Host "$($caServer.ComputerName) could not be contacted." -F Red -B Black
    Write-Warning "Please run the script 'Create-NdesCertificateTemplates.ps1' manually on $($caServer.ComputerName) and then continue this script. Make sure to use the following parameters when running the script:`n`nCreate-NdesCertificateTemplates.ps1 $certArgs"
    Pause
}

# Create root ca cert. Needed for upload to clients and connect the SCEP profile to
#certutil -ca.cert C:\temp\root.cer

# Install NDES Roles
Write-Host "`t Step 8/18 - Installing NDES roles..." -F Yellow
$serverRoles = @("AD-Certificate",
                "ADCS-Device-Enrollment",
                "NET-Framework-45-Features",
                "NET-Framework-45-Core",
                "NET-WCF-Services45",
                "NET-WCF-TCP-PortSharing45",
                "Web-Server",
                "Web-WebServer",
                "Web-Common-Http",
                "Web-Default-Doc",
                "Web-Dir-Browsing",
                "Web-Http-Errors",
                "Web-Static-Content",
                "Web-Http-Redirect",
                "Web-Health",
                "Web-Http-Logging",
                "Web-Log-Libraries",
                "Web-Request-Monitor",
                "Web-Http-Tracing",
                "Web-Performance",
                "Web-Stat-Compression",
                "Web-Security",
                "Web-Filtering",
                "Web-Windows-Auth",
                "Web-App-Dev",
                "Web-Net-Ext",
                "Web-Net-Ext45",
                "Web-Asp-Net",
                "Web-Asp-Net45",
                "Web-ISAPI-Ext",
                "Web-ISAPI-Filter",
                "Web-Mgmt-Tools",
                "Web-Mgmt-Console",
                "Web-Mgmt-Compat",
                "Web-Metabase",
                "Web-WMI",
                "NET-Framework-Features",
                "NET-Framework-Core",
                "NET-HTTP-Activation",
                "NET-Framework-45-ASPNET",
                "NET-WCF-HTTP-Activation45",
                "RSAT",
                "RSAT-Role-Tools",
                "RSAT-ADCS",
                "RSAT-ADCS-Mgmt",
                "PowerShell-V2",
                "WAS",
                "WAS-Process-Model",
                "WAS-NET-Environment",
                "WAS-Config-APIs"
                )

try {
    Install-WindowsFeature -Name $serverRoles -IncludeManagementTools -Verbose -ErrorAction Stop
}
catch {
    Write-Host "Failed to install Server roles. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please manually install following Windows Server roles and continue: `n `
    $($serverRoles -join ", ")"
    Pause
    Break
}


# Configure NDES
Write-Host "`t Step 9/18 - Configuring NDES..." -F Yellow
$ndesServerFqdn = [System.Net.Dns]::GetHostByName($env:computerName).HostName
$ndesCreds = Get-Credential -Message "Please provide a Enterprise Admin account used ONLY for running the Install-AdcsNetworkDeviceEnrollmentService command for NDES configuration where Enterprise Admin permission is required."


$params = @{
    Credential              = $ndesCreds
    ServiceAccountName      = "$env:USERDOMAIN\$($serviceAccount.SamAccountName)"
    ServiceAccountPassword  = $accountPassword
    RAName                  = "$env:USERDOMAIN-NDES-RA"
    #RACountry              = "SV"
    #RACompany              = "$env:USERDOMAIN"
    SigningProviderName     = "Microsoft Strong Cryptographic Provider"
    SigningKeyLength        = 2048
    EncryptionProviderName  = "Microsoft Strong Cryptographic Provider"
    EncryptionKeyLength     = 2048
    Verbose                 = $true
}

if($ndesServerFqdn -notlike $caServer.ComputerName) {
    $params += @{ CAConfig = $caServer.ConfigString }
}

$ErrorActionPreference = "Stop"
try {
    # Requires enterprise admin to configure NDES
    Invoke-Command -Credential $ndesCreds -ArgumentList -ScriptBlock {
        $ndesResult = Install-AdcsNetworkDeviceEnrollmentService @params
    }


    if ($ndesResult.ErrorId -ne 0) {
        Write-Host "A error occurred while configuring NDES. Error message: $($ndesResult.ErrorString)" -F Red -B Black
        Write-Warning "Please manually finish the NDES configuration in Server Manager using the service account with following parameters and continue this script."
        $params
        Pause
    }

    # Set default certificate template to issue from via SCEP
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Cryptography\MSCEP -Name EncryptionTemplate -Value $optionalClientTemplateName -Force         # For Key encipherment
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Cryptography\MSCEP -Name SignatureTemplate -Value $optionalClientTemplateName -Force          # For Digital signature
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Cryptography\MSCEP -Name GeneralPurposeTemplate -Value $optionalClientTemplateName -Force     # For both Key encipherment and Digital signature
}
catch {
    Write-Host "Failed to configure NDES Role. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please manually finish the NDES configuration in Server Manager using the service account with following parameters and continue this script."
    $params
    Pause

    Write-Warning "Please manually change following three registry values and continue this script. `n `
    Key:        HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography\MSCEP `
    Properties: EncryptionTemplate; SignatureTemplate; GeneralPurposeTemplate `
    Value:      $optionalClientTemplateName"
    Pause
}


Write-Host "`t Step 10/18 - Configuring IIS..." -F Yellow
try {
    # Configure request filtering settings in IIS

    Set-WebConfigurationProperty -pspath "IIS:\Sites\Default Web Site" -filter "system.webServer/security/requestFiltering/requestLimits" -name "maxUrl" –value 65534 -Verbose
    Set-WebConfigurationProperty -pspath "IIS:\Sites\Default Web Site" -filter "system.webServer/security/requestFiltering/requestLimits" -name "maxQueryString" –value 65534 -Verbose
    New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\HTTP\Parameters -Name MaxFieldLength -PropertyType DWORD -Value 65534 -Force
    New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\HTTP\Parameters -Name MaxRequestBytes -PropertyType DWORD -Value 65534 -Force
    & IISRESET
}
catch {
    Write-Host "Failed to configure IIS. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please manually set the following Request filtering Feature Settings in IIS, then restart the IIS service and continue this script: `t `
    Maximum URL length: 65534 `
    Maximum query string: 65534"
    Pause
}
$ErrorActionPreference = "Continue"


# Install Entra App Proxy Connector
Write-Host "`t Step 11/18 - Downloading Entra App Proxy Connector..." -F Yellow
$proxyDownloadUrl = "https://download.msappproxy.net/Subscription/d3c8b69d-6bf7-42be-a529-3fe9c2e70c90/Connector/DownloadConnectorInstaller"
$proxyExeFilePath = "$env:USERPROFILE\Downloads\EntraApplicationProxyConnectorInstaller.exe"
try {
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $proxyDownloadUrl -OutFile $proxyExeFilePath -ErrorAction Stop
    $ProgressPreference = 'Continue'

    Write-Host "`t Step 12/18 - Installing Entra App Proxy Connector..." -F Yellow
    $proc = Start-Process -FilePath $proxyExeFilePath -ArgumentList "/passive" -PassThru -ErrorAction Stop
    Write-Host "IMPORTANT! Make sure to authenticate with a global admin account when the OAuth window appear!" -F Yellow -B Black
    $proc.WaitForExit()
}
catch {
    Write-Host "Failed to download and install Entra Proxy Connector. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please download it manually, install it and then continue this script."
    Pause
}

# Create Entra Proxy App
Write-Host "`t Step 13/18 - Creating Entra Proxy App..." -F Yellow
$ErrorActionPreference = "Stop"
try {
    $entraAppDisplayName = "$env:COMPUTERNAME-NDES"
    Connect-AzureAD

    try {
        $onmicrosoftAddress = (Get-AzureADDomain | where {($_.Name -match "\.onmicrosoft\.com$") -AND ($_.Name -notmatch "\.mail\.onmicrosoft\.com$")}).Name | select -First 1
        $entraAppExternalUrl = "https://$($entraAppDisplayName.ToLower() -replace "[^a-zA-Z]")-$($onmicrosoftAddress -replace "\.onmicrosoft\.com$").msappproxy.net/"

        try {
            New-AzureADApplicationProxyApplication -DisplayName $entraAppDisplayName -ExternalUrl $entraAppExternalUrl -InternalUrl "http://$ndesServerFqdn" -ExternalAuthenticationType Passthru
        }
        catch {
            Write-Host "Failed to get AzureADDomain information. Error message: $($_.Exception)" -F Red -B Black
            $failedEntraProxyApp = $true
        }
    }
    catch {
        Write-Host "Failed to get AzureADDomain information. Error message: $($_.Exception)" -F Red -B Black
        $failedEntraProxyApp = $true
    }
}
catch {
    Write-Host "Failed to authenticate to Entra. Error message: $($_.Exception)" -F Red -B Black
    $failedEntraProxyApp = $true
}
$ErrorActionPreference = "Continue"

if ($failedEntraProxyApp) {
    Write-Warning "Please manually create a Entra Proxy Application with the following settings and continue: `n `
    InternalURL:        http://$ndesServerFqdn `
    ExternalURL:        https://$($entraAppDisplayName.ToLower() -replace "[^a-zA-Z]")-<DEFAULT TENANT NAME>.onmicrosoft.com.msappproxy.net `
    Pre-Authentication: Passthru"
    Pause
}




# Request new certificate for server from imported server template
Write-Host "`t Step 14/18 - Requesting new server certificate..." -F Yellow
try {
    $newCert = Get-Certificate -Template $serverTemplateName -SubjectName "CN=$ndesServerFqdn" -DnsName $ndesServerFqdn,$entraAppExternalUrl -CertStoreLocation cert:\LocalMachine\My -ErrorAction Stop
}
catch {
    Write-Host "Failed to issue certificate request from CA with $optionalServerTemplateName template. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please manually issue certificate request for this server with the certificate template '$optionalServerTemplateName' with following additonal properties and store it in personal certificate store: `n`
    Common Name: CN=$ndesServerFqdn `
    DNS Name: $ndesServerFqdn `
    DNS Name: $entraAppExternalUrl"
    Pause
}


# Set SPN
Write-Host "`t Step 15/18 - Setting SPN..." -F Yellow
setspn -s http/$ndesServerFqdn $env:USERDNSDOMAIN\$($serviceAccount.SamAccountName)
if ($LASTEXITCODE -ne 0) {
    Write-Host "Failed to set correct SPN. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please manually set the following SPN for this server and continue: `n `
    setspn -s http/$ndesServerFqdn $env:USERDNSDOMAIN\$($serviceAccount.SamAccountName)"
    Pause
}

# Set IIS Site HTTPS binding
Write-Host "`t Step 16/18 - Configuring IIS HTTPS binding with new server certificate..." -F Yellow
try {
    New-IISSiteBinding -Name "Default Web Site" -BindingInformation "*:443:" -CertificateThumbPrint $newCert.Certificate.Thumbprint -CertStoreLocation "Cert:\LocalMachine\My" -Protocol https -ErrorAction Stop
}
catch {
    Write-Host "Failed to configure https binding. Error message: $($_.Exception)" -F Red -B Black
    Write-Warning "Please manually configure HTTPS binding for Default Web Site with the newly issued certificate and continue. `n `
    Certificate SerialNumber: $($newCert.Certificate.SerialNumber)"
    Pause
}


# Download and install Certificate Connector
Write-Host "`t Step 17/18 - Downloading Intune Certificate Connector..." -F Yellow
$connectorDownloadUrl = "https://go.microsoft.com/fwlink/?linkid=2168535"
$connectorExeFilePath = "$env:USERPROFILE\Downloads\IntuneCertificateConnector.exe"

try {
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $connectorDownloadUrl -OutFile $connectorExeFilePath -ErrorAction Stop
    $ProgressPreference = 'Continue'

    Write-Host "`t Step 18/18 - Installing Intune Certificate Connector..." -F Yellow
    $proc = Start-Process -FilePath $connectorExeFilePath -ArgumentList "/passive /norestart" -PassThru -ErrorAction Stop
    Write-Host "IMPORTANT! Make sure to authenticate with a Entra Global Admin account when the OAuth window appear!" -F Yellow -B Black
    $proc.WaitForExit()
}
catch {
    Write-Warning "Failed to download and install Intune Certificate Connector. Please download and install it manually."
    Pause
}

Write-Host "`t Done!" -F Green